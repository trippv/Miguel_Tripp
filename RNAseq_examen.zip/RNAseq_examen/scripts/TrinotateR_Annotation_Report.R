library(trinotateR)
library(tidyverse)
library(ggpubr)
library(DT)

### Extraccion de informacion del reporte de Trinotate 

# Paso 1: seleccionar el archivo -----------------
trinotate = file.choose()#"Trinotate.xls" #archivo xls con el reporte de trinotate

file = trinotate

# Abrir el report con Trinotate
x <- read_trinotate(file)

# se despliega la tabla con los resultados
summary.tbl <- summary_trinotate(x)
summary.tbl


write.table(summary.tbl, "tablas/Resultados_TrinotateR.txt", row.names = TRUE, sep = "\t")
#####grafica de los resultados de Trinotate
ggdata <- data.frame(x=rownames(summary.tbl), y=summary.tbl$unique)

ggdata <- ggdata %>% 
  arrange(desc(y)) %>% 
  mutate(x=factor(x,x)) 

# step 2 

data.usage <- c("transcript_id","sprot_Top_BLASTX_hit", "sprot_Top_BLASTP_hit", "Pfam", "gene_ontology_blast", "eggnog")

p <- ggplot(ggdata, aes(x=x, y=y)) +
  geom_segment( aes(x=x, xend=x, y=0, yend=y ), 
                color = ifelse(ggdata$x %in% data.usage, "orange", "grey"), 
                size = ifelse(ggdata$x %in% data.usage, 1.3, 0.7) ) +
  geom_point( color = ifelse(ggdata$x %in% data.usage, "orange", "grey"), 
              size=ifelse(ggdata$x %in% data.usage, 5, 2) ) +
  theme_light() +
  coord_flip() +
  theme(
    legend.position="none",
    panel.grid.major.y = element_blank(),
    panel.border = element_blank(),
    axis.ticks.y = element_blank()
  ) +
  xlab("") +
  ylab("Number of Sequences") +
  ggtitle("Unigenes Data distribution \nData usage through this analysis is colored with orange")


print(p)

# Guardar la figura dentro de la carpeta de figuras
ggsave("figuras/Trinotate_results.pdf")



# Paso 2: Extraer resultados de Blast, GO, pfam, etc ------------------------------


pfam <- split_pfam(x)
spfam <- summary_pfam(pfam)

go <- split_GO(x,hit = "gene_ontology_blast")
gos <- summary_GO(go)

blastx <- split_blast(x, "sprot_Top_BLASTX_hit") 
sblastx <- summary_blast(blastx)

blastp <- split_blast(x, "sprot_Top_BLASTP_hit")
sblastp <- summary_blast(blastp)


# Guardar los resultados de blastx
write.table(blastx, "tablas/Blastx_anotacion.txt", sep = "\t", row.names = FALSE)


# 3: Clasificación taxonomica de los resultados de Blast ------------------


# Solamente basados en el genero

genus.p = blastp %>%
  count(genus, sort = TRUE) %>%
  rename(Genus = genus, Number = n) %>%
  group_by(Genus) %>%
  tally(Number, sort = TRUE) %>%
  group_by(Genus = factor(c(Genus[1:35], rep("Other", n() - 35)),
                            levels = c(Genus[1:35], "Other"))) %>%
  tally(n) 


#plot for taxonomic classificacion Blastp
genus.p.plot = ggplot(genus.p, aes(x = Genus, y = n)) +
  geom_bar(stat="identity", fill = "steelblue") +
  coord_flip() + xlab("Genus") + ylab("Number of BlastP Hits") +
  theme_classic()+
  theme(axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12))
genus.p.plot


# ====== Taxonomic classification on BlastX top hit hits=======
# only based on genus
genus.x = blastx %>%
  count(genus, sort = TRUE) %>%
  rename(Genus = genus, Number = n) %>%
  group_by(Genus) %>%
  tally(Number, sort = TRUE) %>%
  group_by(Genus = factor(c(Genus[1:35], rep("Other", n() - 35)),
                          levels = c(Genus[1:35], "Other"))) %>%
  tally(n) 



genus.x.plot = ggplot(genus.x, aes(x = Genus, y = n)) +
  geom_bar(stat="identity", fill = "steelblue") +
  coord_flip() + xlab("Genus") + ylab("Number of BlastX Hits") +
  theme_classic()+
  theme(axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12))
genus.x.plot

#####combined plot; blastx and blastp
genus.x$Type <-"Transcript"
genus.p$Type <-"ORF"

plot <- rbind(genus.p, genus.x)


ggplot(plot, aes(x = n, y = Genus, fill = Type))+
  geom_bar(stat="identity")+
  theme_minimal()+
  scale_fill_manual(values = c("lightblue", "darkcyan"))+
  #facet_grid(.~ Type)+
  labs(y = "Genero", x = "Numero de secuencias")+
  theme(axis.text.y = element_text(hjust = 1, size = 7),
        axis.text.x = element_text(angle = 45))

  
ggsave("figuras/Resultado_Taxonomia_blast.pdf")
  
  
##############################################
###select only the mollucs for the blast hits
blastp.teleost = blastp %>%
  select(transcript, lineage, genus) %>%
  filter(str_detect(lineage, "Teleostei")) %>%
  count(genus, sort = TRUE) %>%
  rename(Genus = genus, Number = n) %>%
  group_by(Genus) %>%
  tally(Number, sort = TRUE) %>%
  group_by(Genus = factor(c(Genus[1:35], rep("Other", n() - 35)),
                          levels = c(Genus[1:35], "Other"))) %>%
  tally(n) 

  
###select only the mollucs for the blast hits
blastx.teleost = blastx %>%
  select(transcript, lineage, genus) %>%
  filter(str_detect(lineage, "Teleostei")) %>%
  count(genus, sort = TRUE) %>%
  rename(Genus = genus, Number = n) %>%
  group_by(Genus) %>%
  tally(Number, sort = TRUE) %>%
  group_by(Genus = factor(c(Genus[1:35], rep("Other", n() - 35)),
                          levels = c(Genus[1:35], "Other"))) %>%
  tally(n) 





blastx.teleost$Type <-"BlastX"
blastp.teleost$Type <-"BlastP"

plot.teleost <- rbind(blastx.teleost, blastp.teleost)

ggplot(plot.teleost, aes(x = n, y = reorder(Genus, - n), fill = Type))+
  geom_bar(stat="identity")+
  theme_minimal()+
  scale_fill_manual(values = c("lightblue", "darkcyan"))+
  #facet_grid(.~ Type)+
  labs(y = "Genero", x = "Numero de secuencias")+
theme(axis.text.y = element_text(hjust = 1, size = 7),
      axis.text.x = element_text(angle = 45))


ggsave("figuras/Resultado_Taxonomia_teleost_blast.pdf")
######################NOGGS ANNOTATIONS#################

#####plot NOGGS######
data(cogs) #Del paquete TrinotateR. COG function classes and color scheme. Se necesita para la funcion plot_NOGs
download.file("https://raw.githubusercontent.com/RJEGR/infovis/master/NOG.annotations.tsv", "NOG.annotations.tsv")
egg <- read.table("NOG.annotations.tsv", sep="\t", stringsAsFactors=FALSE, quote="")
names(egg) <- c("db", "nog", "proteins", "species", "class", "description")


pdf("figuras/Resultados_NOGS.pdf", width = 14)
plot_NOGs(x, "transcript_id")
dev.off()

# ====
plotgos <- head(gos[order(-gos$transcripts),], 100)

bar <- ggbarplot(plotgos, "name", "transcripts",
                 fill = "ontology", 
                 color = "ontology",
                 xlab = "Name",
                 ylab = "Number of transcripts",
                 palette = "jco",            # jco journal color palett. see ?ggpar
                 sort.val = "asc",           # Sort the value in dscending order
                 sort.by.groups = TRUE,
                 x.text.angle = 45,           # Rotate vertically x axis text
                 title = "Highest ontologies (top 100)")+
  theme(axis.text.x = element_text(hjust = 1, size = 8, angle = 90))
bar

ggsave("figuras/Resultados_GOs.pdf", width = 12)


#Busqueda de dominios proteicos
z <- data.frame(spfam)
z$pfam <- paste0('<a href="http://pfam.xfam.org/family/', z$pfam, '">', z$pfam,  '</a>')


widget <- datatable(
  z, 
  escape=1,
  extensions = 'Buttons', options = list(
    pageLength = 25,  
    dom = 'Bfrtip',
    buttons = 
      list('copy', 'print', list(
        extend = 'collection',
        buttons = c('csv', 'excel'),
        text = 'Download'
      ))
    
  )
)

htmlwidgets::saveWidget(widget, paste0(file, ".pfam.html"))


# Anotacion de transcritos expresados diferencialmente --------------------

# 1. Abrir los archivos de cada condicion de la carpeta expreson diferencial

## PAU30_vs_ctl
read.table("expresion_diferencial/PAU30_Vs_Control.todos_genes_GEF.txt", 
           sep = "\t", row.names = 1) %>% 
  rownames_to_column("gene") %>% 
  filter(!between(logFC, -2, 2),
         FDR < 0.1) %>% 
  inner_join(blastx, by = "gene") %>% 
  select(-domain, -lineage) %>% 
  distinct(gene, .keep_all = TRUE) %>% 
  separate(uniprot, into = c("gene_symbol", "taxa"), sep = "_") %>% 
  write.table("tablas/PAU30_vs_ctl_blast.txt", sep = "\t", row.names = FALSE)


## pau33_vs_ctl
read.table("expresion_diferencial/PAU33_Vs_Control.todos_genes_GEF.txt", 
           sep = "\t", row.names = 1) %>% 
  rownames_to_column("gene") %>% 
  filter(!between(logFC, -2, 2),
         FDR < 0.1) %>% 
  inner_join(blastx, by = "gene") %>% 
  select(-domain, -lineage) %>% 
  distinct(gene, .keep_all = TRUE) %>% 
  separate(uniprot, into = c("gene_symbol", "taxa"), sep = "_") %>% 
  write.table("tablas/PAU33_vs_ctl_blast.txt", sep = "\t", row.names = FALSE)

