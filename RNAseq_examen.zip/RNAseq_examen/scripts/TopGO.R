library(topGO)
library(tidyverse)

# Funcion para el enriquecimiento funcionl 
# Enriquecimiento de genes sobre expresados -------------------------------------


TopgoEnrich <- function(x, nombre) {
  
  # 1 lista de genes
  gene_list<- x
  
  # comparar genes de la lista contra el universo
  compared_genes <- factor(as.integer(bg_genes %in% gene_list))
  names(compared_genes) <- bg_genes
  
  # Create topGO object
  GOdata <- new("topGOdata", ontology = "BP", allGenes = compared_genes,
                annot = annFUN.gene2GO, gene2GO = GOesByID)
  
  # Run Fisher test
  resultFisher <- runTest(GOdata, algorithm = "classic", statistic = "fisher")
  
  # Create and print table with enrichment result
  Fisher_res <- GenTable(GOdata, classicFisher = resultFisher, topNodes = Nodes)
  
  
  
  ## Saving  list ####
  Results_table <- Fisher_res %>%
    mutate(Category = "BP") %>%
    dplyr::rename(Pvalue = classicFisher) %>%
    mutate(Genes = NA)
  
  
  #create a vector of genes (transcripts) from each category
  GOnames <- as.vector(Fisher_res$GO.ID)
  allGenes <- genesInTerm(GOdata, GOnames)
  significantGenes <- list()
  for(i in 1:Nodes){
    significantGenes[[i]] <- allGenes[[i]][allGenes[[i]] %in% as.vector(gene_list)]
  }
  names(significantGenes) <- Fisher_res$Term
  
  
  GOterms <- Results_table$Term
  for(i in 1:length(GOterms)) {
    GOterm <- GOterms[i]
    GO_gene_list <- paste(significantGenes[[GOterm]], collapse = ",")
    Results_table[i,"Genes"] <- GO_gene_list
  }
  
  file_name <- paste0("tablas/", nombre, "_TopGo.txt")
  
  write.table(Results_table,
              file = file_name,
              sep = "\t", row.names = FALSE)
  
}






# 1: Importar los archivos -------------------------------------------------------------

PAU30_vs_ctl <- read.table("expresion_diferencial/PAU30_Vs_Control.todos_genes_GEF.txt", 
                        sep = "\t", row.names = 1) %>% 
  rownames_to_column("gene") %>% 
  filter(!between(logFC, -2, 2),
         FDR < 0.1)

PAU33_vs_ctl <- read.table("expresion_diferencial/PAU33_Vs_Control.todos_genes_GEF.txt", 
                           sep = "\t", row.names = 1) %>% 
  rownames_to_column("gene") %>% 
  filter(!between(logFC, -2, 2),
         FDR < 0.1)

#2:  Definir el background (todos los transcritos anotados) ----------------------------------


file_background <- "data/Trinotate_GO_annotations.txt" # EL archivo generado mediante e pipeline de trinotate es el mas adecuado


data <- read.table(file_background, sep = "\t", header = FALSE, row.names = NULL, skip = 1)
colnames(data) <- c("ID", "GO_P_ID")
data$GO_P_ID <- as.character(gsub(';', ', ', data$GO_P_ID))


Nodes <- 50 # numero de procesos a mostrar


# Create temp file

file_temp <- paste0(file_background,"2")
write.table(data, file = file_temp, sep = "\t", quote = FALSE, col.names = FALSE, row.names = FALSE)

# Obtener la anotacion del universo
GOesByID <- readMappings(file = file_temp)
bg_genes <- names(GOesByID)



# Ejecuta la función de TopGO para ambos contrastes. Los resultados se guardaran en la carpta de tablas

TopgoEnrich(PAU30_vs_ctl$gene, "PAU30_vs_control")

TopgoEnrich(PAU33_vs_ctl$gene, "PAU33_vs_control")

