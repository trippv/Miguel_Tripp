
#Este script instalara los paquetes que necesitaremos para las clases

#Instalar EdgeR de bioconductor

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("topGO")

#Nota: puede que te pida que actualices algunos otros paqeutes

#Instalar devtools
install.packages("devtools")

#instalar TrinotateR
devtools::install_github("cstubben/trinotateR", force = TRUE)

#Install gplots
install.packages("gplots")

#install tidyverse
install.packages("tidyverse")

#Instal color brewer
install.packages("RColorBrewer")

#install ggpubr
install.packages("ggpubr")



#comprueba que esten listos todos los paquetes
packages <- c("trinotateR", "tidyverse", "gplots", "RColorBrewer", "ggpubr")


if (length(setdiff(packages, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(packages, rownames(installed.packages())))  
} else {print("todo listo!")}
